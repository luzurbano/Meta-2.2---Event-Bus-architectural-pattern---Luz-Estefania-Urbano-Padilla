
package Events;

public record BandaTocandoEvent(String nombreBanda, String nombreCancion, int duracionSegundos) {

}
