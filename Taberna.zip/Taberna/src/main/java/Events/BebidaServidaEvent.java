
package Events;

public record BebidaServidaEvent(int mesaId, String bebida) {

}


