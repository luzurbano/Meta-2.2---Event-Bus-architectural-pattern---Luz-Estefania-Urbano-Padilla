
package Events;

public record ComidaPreparadaEvent(int pedidoId, String plato) {

}

